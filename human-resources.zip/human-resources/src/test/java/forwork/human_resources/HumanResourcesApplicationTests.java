package forwork.human_resources;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HumanResourcesApplicationTests {

	@Test
	void contextLoads() {
	}

}
